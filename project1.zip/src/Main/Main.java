package Main;

import PageFrame.FrameBase;
import PageFrame.FramePreference;

public class Main {
	public static void main(String[] args) {
		FrameBase.getInstance(new FramePreference());
	}
}
